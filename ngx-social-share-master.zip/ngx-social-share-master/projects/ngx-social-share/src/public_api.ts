/*
 * Public API Surface of ngx-social-share
 */

export * from './lib/ngx-social-share.module';
